package superimposer.library;

public class Data {

    public double[] data;

    public Data(double... data) {
        this.data = data;
    }

}
